﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class activityidaddedinhblactivitytable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ActivityId",
                table: "HblActivity",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_HblActivity_ActivityId",
                table: "HblActivity",
                column: "ActivityId");

            migrationBuilder.AddForeignKey(
                name: "FK_HblActivity_ActivityMaster_ActivityId",
                table: "HblActivity",
                column: "ActivityId",
                principalTable: "ActivityMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_HblActivity_ActivityMaster_ActivityId",
                table: "HblActivity");

            migrationBuilder.DropIndex(
                name: "IX_HblActivity_ActivityId",
                table: "HblActivity");

            migrationBuilder.DropColumn(
                name: "ActivityId",
                table: "HblActivity");
        }
    }
}
