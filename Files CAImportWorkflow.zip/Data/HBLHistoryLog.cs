﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public class HBLHistoryLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string HBLActivityId { get; set; }
        public string CurrentStatus { get; set; }
        public string? Comment { get; set; }
        public string? EnterBy { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? EnterDate { get; set; }

        [ForeignKey("HBLActivityId")]
        public virtual HblActivity HblActivity { get; set; }
        [ForeignKey("EnterBy")]
        public virtual User User { get; set; }
        
    }
}
