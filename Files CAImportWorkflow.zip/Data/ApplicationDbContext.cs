﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CAImportWorkflow.Data
{
    public partial class ApplicationDbContext :IdentityDbContext<User>
    {
        public ApplicationDbContext()
        {

        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<FileEntry> FileEntry{ get; set; }
        public virtual DbSet<HblEntry> HblEntry { get; set; }
        public virtual DbSet<ActivityMaster> ActivityMaster { get; set; }
        public virtual DbSet<FileActivity> FileActivity { get; set; }
        public virtual DbSet<HblActivity> HblActivity{ get; set; }
        public virtual DbSet<ThreadMaster> ThreadMaster { get; set; }
        public virtual DbSet<ThreadRelation> ThreadRelation { get; set; }
        public virtual DbSet<User> User { get; set; }
        public virtual DbSet<ActivityMapping> ActivityMapping { get; set; }
        public virtual DbSet<LocationMaster> LocationMaster { get; set; }
        public virtual DbSet<UserLocationRelation> UserLocationRelation { get; set; }
        public virtual DbSet<FileHistoryLog> FileHistoryLog { get; set; }
        public virtual DbSet<HBLHistoryLog> HBLHistoryLog { get; set; }


    }
}
