﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CAImportWorkflow.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<User> userManger;
        private readonly SignInManager<User> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;
        public ApplicationDbContext _ctx;


        public AccountController(UserManager<User> userManger, SignInManager<User> signInManager, RoleManager<IdentityRole> roleManager, ApplicationDbContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpGet]

        public IActionResult Index()
        {
            var result = _ctx.Users.Select(x => new RegisterViewModel
            {
                Id = x.Id,
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                Wnsid = x.Wnsid,
                RoleList = roleManager.Roles.ToList(),
                assingedRoleList = _ctx.UserRoles.Where(y => y.UserId == x.Id).Select(x => x.RoleId).ToList(),
                threadMasters = _ctx.ThreadMaster.Select(z => new ThreadMaster
                { Id = z.Id, Name = z.Name }).ToList(),
                assignedThreads = _ctx.ThreadRelation.Where(z => z.UserId == x.Id && z.IsActive == true).Select(z => z.ThreadId).ToList(),
                locationMasterList = _ctx.LocationMaster.Select(z => new LocationMaster
                { Id = z.Id, Name = z.Name }).ToList(),
                assignedLocation = _ctx.UserLocationRelation.Where(y => y.UserId == x.Id).Select(x => x.LocationId).ToList(),

            }).ToList();

            return View(result);
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {

            if (ModelState.IsValid)
            {
                var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
                if (result.Succeeded)
                {
                    var user = await userManger.FindByNameAsync(model.CitrixId);
                    var roles = await userManger.GetRolesAsync(user);

                    if (roles.Count != 0)
                    {
                        if (roles.Count() == 1)
                        {
                            if (roles[0].ToString().ToUpper() == "ADMIN")
                            {
                                return RedirectToAction("AdminDashboard", "Admin");
                            }
                            else if (roles[0].ToString().ToUpper() == "USER")
                            {
                                return RedirectToAction("UserThread", "User");
                            }
                        }
                        else
                            return RedirectToAction("SelectRole", "User");
                    }
                    else
                        ModelState.AddModelError(string.Empty, "No roles assigned, Please contact Admin");

                }
                ModelState.AddModelError("", "Invalid Login Attempt");
                return View(model);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }


        }

        [HttpGet]
        public IActionResult Register()
        {
            ViewData["roles"] = roleManager.Roles.ToList();


            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            
            var user = new User
            {
                CitrixId = model.CitrixId.Trim(),
                Wnsid = model.Wnsid,
                UserName = model.UserName.ToString().Trim(),
                DocContact = string.Empty,
            };

            var result = await userManger.CreateAsync(user);
            _ctx.SaveChanges();
            if (result.Succeeded)
            {
                return RedirectToAction("Index", "Account");
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
            //}

            return View(model);
        }

        [HttpPost]
        public async Task<JsonResult> UpdateRoles(UpdateRoleModel assignedRole)
        {
            var userrole = _ctx.UserRoles.Where(x => x.UserId == assignedRole.UserId).ToList();
            try
            {
                _ctx.RemoveRange(userrole);

                if (assignedRole.RoleList != null)
                    foreach (var multi in assignedRole.RoleList)
                    {
                        _ctx.UserRoles.Add(new IdentityUserRole<string>
                        {
                            UserId = assignedRole.UserId,
                            RoleId = multi.RoleId,
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }

        [HttpPost]
        public async Task<JsonResult> UpdateThread(UpdateThreadModel assignedThread)
        {
            var threadRelation = _ctx.ThreadRelation.Where(x => x.UserId == assignedThread.UserId).ToList();

            try
            {
                _ctx.RemoveRange(threadRelation);

                if (assignedThread.ThreadList != null)
                    foreach (var multi in assignedThread.ThreadList)
                    {
                        _ctx.ThreadRelation.Add(new ThreadRelation
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserId = assignedThread.UserId,
                            ThreadId = multi.ThreadId,
                            IsActive = true
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }


        [HttpPost]
        public async Task<JsonResult> UpdateLocation(UpdateLocationModel assignedLocation)
        {
            var locationRelation = _ctx.UserLocationRelation.Where(x => x.UserId == assignedLocation.UserId).ToList();

            try
            {
                _ctx.RemoveRange(locationRelation);

                if (assignedLocation.LocationList != null)
                    foreach (var multi in assignedLocation.LocationList)
                    {
                        _ctx.UserLocationRelation.Add(new UserLocationRelation
                        {
                            Id = Guid.NewGuid().ToString(),
                            UserId = assignedLocation.UserId,
                            LocationId = multi.LocationId,
                            Sequance = 999
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }

        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");

        }
    }
}
