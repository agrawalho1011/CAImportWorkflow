﻿using Microsoft.AspNetCore.Mvc;

namespace CAImportWorkflow.Controllers
{
    public class ErrorController : Controller
    {
        //public IActionResult Index(int statusCode)
        //{
        //    if (statusCode == 404)
        //    {
        //        return View("Index");
        //    }
        //    else

        //        return View();
        //    // Handle other status codes as needed
        //}

        [Route("Error/{statusCode}")]
        public IActionResult HttpStatusCodeHandler(int statusCode)
        {
            switch (statusCode)
            {
                case 404:
                    ViewBag.ErrorMessage = "Sorry, the resource you requested could not be found";

                    return View("Index");
                    break;
                case 500:
                    return View("ServerError");
                    break;
            }
            return View();
        }
    }



}
