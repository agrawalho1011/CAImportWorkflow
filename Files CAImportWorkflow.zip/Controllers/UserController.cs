﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Data;
using System.Globalization;
using System.Reflection;
using System.Security.Claims;
using System.Linq.Dynamic.Core;

namespace CAImportWorkflow.Controllers
{
    public class UserController : Controller
    {
        ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor)
        {
            _ctx = ctx;
            _httpContextAccessor = httpContextAccessor;

        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _ctx.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _ctx.Roles.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()

            }).ToList();
            return View();
        }
        public IActionResult UserThread()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["UserThread"] = _ctx.ThreadRelation.Where(x => x.UserId == userid).Select(x => new ThreadMaster
            {
                Id = x.ThreadMaster.Id,
                Name = x.ThreadMaster.Name,

            }).ToList();
            return View();
        }


        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper() == "ADMIN")
            {
                return RedirectToAction("AdminDashboard", "Admin");
            }
            else if (RoleName.ToUpper() == "USER")
            {
                return RedirectToAction("UserThread", "User");
            }
            else
            {
                return RedirectToAction("GetItem", "Invoice");
            }

            return View();
        }

        [HttpGet]
        public IActionResult UserAction(string ThreadName)
        {
            ViewData["HblactivityList"] = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.BasedOn == "HBL" && x.ThreadId == ThreadName).Select(x => new ActivityMaster
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                ThreadId = x.ThreadId,
            }).ToList();

            ViewData["FileactivityList"] = _ctx.ActivityMaster.Where(x => x.IsActive == true && x.BasedOn == "File" && x.ThreadId == ThreadName).Select(x => new ActivityMaster
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                ThreadId = x.ThreadId,
            }).ToList();

            ViewData["ActivityMappingList"] = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.IsActive == true && x.FileActivityMaster.BasedOn == "File" && x.FileActivityMaster.ThreadId == ThreadName).ToList();

            return View();
        }

        [HttpGet]
        public JsonResult CheckHBLActivityStatus(string fileActivityId)
        {
            List<ActivityMapping> activityMappings = _ctx.ActivityMapping.Where(x => x.IsActive == true && x.FileActivityId == fileActivityId).ToList();
            return Json(activityMappings);

        }

        [HttpGet]
        public JsonResult ResetFileActivityStatus(string hblActivityId)
        {
            List<ActivityMapping> activityMappings = _ctx.ActivityMapping.Where(x => x.IsActive == true && x.HBLActivityId == hblActivityId).ToList();
            return Json(activityMappings);
        }

        static DateTime GetDate(string Column0)
        {
            DateTime dt;
            if (!DateTime.TryParseExact(Column0, "yyyy/dd/MM hh:mm:ss tt",
                       CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out dt))
            {
                dt = DateTime.MinValue;
            }

            return dt;
        }

        [HttpGet]
        public JsonResult GetNextFile(string threadmasterId)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);


            SubmitDataViewModel submitDataViewModel = new SubmitDataViewModel();

            submitDataViewModel.HBLDataSubmit = new List<HblDataSubmitViewModel>();
            submitDataViewModel.FileActivityStatusSubmit = new List<FileActivityStatus>();
            submitDataViewModel.Activities = new List<ActivityMaster>();
            submitDataViewModel.file = new List<FileData>();

            List<HblEntry> hblEntryResult = new List<HblEntry>();
            List<FileActivity> fileActresult = new List<FileActivity>();
            List<HblActivity> hblActResult = new List<HblActivity>();

            submitDataViewModel.Activities = _ctx.ActivityMaster.Where(x => x.ThreadId == threadmasterId.Trim()).ToList();
            DateTime dtETA;

            var allocate = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == userid && x.ActivityMaster.ThreadId == threadmasterId.Trim()).OrderBy(x => x.FileEntry.EtaAtPod).Select(x => new { x.FileId, x.FileEntry.EtaAtPod }).Distinct().FirstOrDefault();///Distinct Removed

            if (allocate == null)
            {
                allocate = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == null && x.ActivityMaster.ThreadId == threadmasterId.Trim()).OrderBy(x => x.FileEntry.EtaAtPod).Select(x => new { x.FileId, x.FileEntry.EtaAtPod }).Distinct().FirstOrDefault();///Distinct Removed

                if (allocate != null)
                {
                    List<FileActivity> fileActivityList = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == null && x.ActivityMaster.ThreadId == threadmasterId.Trim() && x.FileId == allocate.FileId.ToString()).OrderBy(x => x.FileEntry.EtaAtPod).ToList();

                    foreach (FileActivity activity in fileActivityList)
                    {
                        activity.UserId = userid;
                        activity.StartTime = DateTime.UtcNow;
                        _ctx.FileActivity.Update(activity);
                    }
                    _ctx.SaveChanges();

                    allocate = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.CurrentStatus == "WIP" && x.UserId == userid && x.ActivityMaster.ThreadId == threadmasterId.Trim()).OrderBy(x => x.FileEntry.EtaAtPod).Select(x => new { x.FileId, x.FileEntry.EtaAtPod }).Distinct().FirstOrDefault(); ///Distinct Removed
                }
            }

            if (allocate != null)
            {
                submitDataViewModel.file = _ctx.FileEntry.Where(x => x.Id == allocate.FileId.ToString()).Select(x => new FileData { FileNo = x.FileNo, Id = x.Id, ContainerNo = x.ContainerNo, pol = x.Pol, pod = x.Pod, ETAatPOD = x.EtaAtPod, Hblcount = x.Hblcount }).ToList();
                fileActresult = _ctx.FileActivity.Include(y => y.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == submitDataViewModel.file[0].Id.ToString() && x.ActivityMaster.ThreadId == threadmasterId.Trim()).ToList();

                foreach (FileActivity fileActivity in fileActresult)
                {
                    fileActivity.StartTime = DateTime.UtcNow;
                    _ctx.FileActivity.Update(fileActivity);

                    submitDataViewModel.FileActivityStatusSubmit.Add(new FileActivityStatus
                    {
                        ActivityId = fileActivity.ActivityId.ToString(),
                        CurrentStatus = fileActivity.CurrentStatus,
                        Comments = fileActivity.Comment == null ? "" : fileActivity.Comment
                    });
                }

                hblEntryResult = _ctx.HblEntry.Where(x => x.FileGuidId == submitDataViewModel.file[0].Id.ToString()).ToList();
                foreach (HblEntry hbl in hblEntryResult)
                {
                    hblActResult = _ctx.HblActivity.Include(y => y.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.HblId == hbl.Id).ToList();

                    List<HBLActivityStatus> hBLActivityStatuses = new List<HBLActivityStatus>();

                    foreach (HblActivity hblActivity in hblActResult)
                    {
                        HBLActivityStatus hBLActivityStatus = new HBLActivityStatus
                        {
                            ActivityId = hblActivity.ActivityId.ToString(),
                            Status = hblActivity.CurrentStatus,
                            HblComments = hblActivity.Comment
                        };

                        hBLActivityStatuses.Add(hBLActivityStatus);
                    }

                    if (hBLActivityStatuses.Count > 0)
                    {
                        HblDataSubmitViewModel hblDataSubmitViewModel = new HblDataSubmitViewModel
                        {
                            HblNo = hbl.Hblno,
                            IsDap = hbl.IsDap == true ? "Yes" : "No",
                            HBLActivityStatuses = hBLActivityStatuses
                        };
                        submitDataViewModel.HBLDataSubmit.Add(hblDataSubmitViewModel);

                    }
                    else
                    {
                        HblDataSubmitViewModel hblDataSubmitViewModel = new HblDataSubmitViewModel
                        {
                            HblNo = hbl.Hblno,
                            IsDap = hbl.IsDap == true ? "Yes" : "No",
                        };
                        submitDataViewModel.HBLDataSubmit.Add(hblDataSubmitViewModel);
                    }



                }
            }

            return Json(submitDataViewModel);

        }

        [HttpPost]
        public JsonResult SaveData(SubmitDataViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (model.HBLDataSubmit != null)
            {
                foreach (HblDataSubmitViewModel hblvm in model.HBLDataSubmit)
                {
                    string hblId = "";

                    if (hblvm.HblNo != null && hblvm.HblNo.Trim() != "")
                    {
                        HblEntry hblEntry = _ctx.HblEntry.Where(x => x.Hblno == hblvm.HblNo).FirstOrDefault();
                        if (hblEntry == null)
                        {
                            HblEntry hblentry = new HblEntry
                            {
                                Id = Guid.NewGuid().ToString(),
                                FileGuidId = model.file[0].Id,
                                Hblno = hblvm.HblNo,
                                IsDap = hblvm.IsDap.ToUpper() == "YES" || hblvm.IsDap.ToUpper() == "TRUE" ? true : false,
                                CreatedBy = userid,
                                CreatedDate = DateTime.Now.ToUniversalTime(),
                            };

                            hblId = hblentry.Id;

                            _ctx.HblEntry.Add(hblentry);
                        }
                        else
                        {
                            hblId = hblEntry.Id;
                            hblEntry.Hblno = hblvm.HblNo;
                            hblEntry.IsDap = hblvm.IsDap.ToUpper() == "YES" || hblvm.IsDap.ToUpper() == "TRUE" ? true : false;
                            hblEntry.CreatedDate = DateTime.Now.ToUniversalTime();
                            _ctx.HblEntry.Update(hblEntry);
                        }

                        foreach (HBLActivityStatus status in hblvm.HBLActivityStatuses)
                        {
                            if (status.Status != "" && !status.Status.Contains("Select"))
                            {

                                HblActivity hblact = _ctx.HblActivity.Where(x => x.ActivityId == status.ActivityId && x.HblId == hblId).FirstOrDefault();
                                if (hblact == null)
                                {
                                    HblActivity hblActivity = new HblActivity
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        HblId = hblId,
                                        ActivityId = status.ActivityId,
                                        CurrentStatus = status.Status,
                                        Comment = status.HblComments,
                                        StartTime = status.StartTime,
                                        EndTime = DateTime.Now.ToUniversalTime(),
                                        EnterBy = userid,
                                        EnterDate = DateTime.Now.ToUniversalTime()
                                    };
                                    _ctx.HblActivity.Add(hblActivity);
                                }
                                else
                                {
                                    hblact.StartTime = status.StartTime;
                                    hblact.CurrentStatus = status.Status;
                                    hblact.Comment = status.HblComments;
                                    hblact.EndTime = DateTime.Now.ToUniversalTime();

                                    _ctx.HblActivity.Update(hblact);
                                }
                            }
                        }
                    }
                    _ctx.SaveChanges();
                }


            }

            FileEntry fileEntry = _ctx.FileEntry.Where(x => x.Id == model.file[0].Id).FirstOrDefault();
            if (fileEntry != null)
            {
                fileEntry.FileNo = model.file[0].FileNo;
                fileEntry.ContainerNo = model.file[0].ContainerNo;
                fileEntry.EtaAtPod = model.file[0].ETAatPOD;
                fileEntry.Pol = model.file[0].pol;
                fileEntry.Pod = model.file[0].pod;

                _ctx.FileEntry.Update(fileEntry);
                string firstActivity = "";

                bool flag = false;
                foreach (var fileActivityStatus in model.FileActivityStatusSubmit)
                {
                    if (!fileActivityStatus.CurrentStatus.Contains("Select"))
                    {
                        if (!flag)
                        {
                            firstActivity = fileActivityStatus.ActivityId;
                            flag = true;
                        }

                        FileActivity fileActivity = _ctx.FileActivity.Where(x => x.ActivityId == fileActivityStatus.ActivityId && x.FileId == model.file[0].Id).FirstOrDefault();

                        fileActivity.StartTime = fileActivityStatus.StartTime;
                        fileActivity.CurrentStatus = fileActivityStatus.CurrentStatus;
                        fileActivity.Comment = fileActivityStatus.Comments;
                        fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                        _ctx.FileActivity.Update(fileActivity);
                        _ctx.SaveChanges();
                    }
                }

                var CurrentThreadId = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == firstActivity).Select(x => x.ThreadMaster).FirstOrDefault();

                ThreadMaster threadMaster = _ctx.ThreadMaster.Include(x => x.ActivityMaster.Where(x => x.BasedOn == "File")).Where(x => x.Sequance > CurrentThreadId.Sequance).OrderBy(i => i.Sequance).FirstOrDefault();//_ctx.ThreadMaster.SkipWhile(x => x.Id != CurrentThreadId).Skip(1).FirstOrDefault();
                if (threadMaster != null && threadMaster.ActivityMaster.Count > 0)
                {
                    foreach (ActivityMaster activity in threadMaster.ActivityMaster.ToList())
                    {

                        FileActivity fileNextActivity = _ctx.FileActivity.Where(x => x.ActivityId == activity.Id && x.FileId == model.file[0].Id).FirstOrDefault();

                        if (fileNextActivity == null)
                        {
                            _ctx.FileActivity.Add(new FileActivity
                            {
                                Id = Guid.NewGuid().ToString(),
                                FileId = model.file[0].Id,
                                ActivityId = activity.Id,
                                CurrentStatus = "WIP",
                                Comment = null,
                                UserId = null,
                                EnterDate = DateTime.Now.ToUniversalTime(),
                                StartTime = null,
                                EndTime = null
                            });
                        }
                    }
                    _ctx.SaveChanges();
                }

            }
            return Json("Success");
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {

            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Where(x => x.BasedOn == "File").OrderBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL").OrderBy(x => x.Name).ToList();
            foreach (var item in fileActivity)
            {
                userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                {
                    Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                    UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                    WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                });
            }


            foreach (var item in hblActivity)
            {
                userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                {
                    Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                    UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                    WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                });
            }
            return View(userActivityStatus);
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {

            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Where(x => x.BasedOn == "File").OrderBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL").OrderBy(x => x.Name).ToList();
            if (StartDate != null && EndDate != null)
            {
                var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }

                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }
            else
            {
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }


                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }
            return Json(userActivityStatus);
        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Where(x => x.BasedOn == "File").OrderBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL").OrderBy(x => x.Name).ToList();
            if (StartDate != null && EndDate != null)
            {
                var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }

                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }
            else
            {
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }


                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }

            var fileStatus = userActivityStatus.GetFileActivityStatus.Select(x => new FileStatusList
            {
                Activity = x.Activity,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed

            }).ToList();

            var hblStatus = userActivityStatus.GetHBLActivityStatus.Select(x => new HBLStatusList
            {
                Activity = x.Activity,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed

            }).ToList();
            DataTable FileActivityStatus = ToDataTable(fileStatus);
            DataTable HBLActivityStatus = ToDataTable(hblStatus);

            using (XLWorkbook wb = new XLWorkbook())
            {
                FileActivityStatus.TableName = "File Activity Status";
                HBLActivityStatus.TableName = "HBL Activity Status";
                var wsData = wb.Worksheets.Add(FileActivityStatus);
                var ws = wb.Worksheets.Add(HBLActivityStatus);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"UserActivityStatus-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status, string startDate, string fileNo, string containerNo, string hblNo)
        {
            DateTime DateTime = Convert.ToDateTime(startDate);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            var userName = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault();
            if (activityType == "HBL")
            {
                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).Include(x => x.User).Include(x => x.HblEntry)
                    .Include(x => x.HblEntry.FileGuid).Include(x => x.HblEntry.FileGuid.FileActivity)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment == null ? "" : x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        FileNo = x.HblEntry.FileGuid.FileNo,
                        ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                        hblNo = x.HblEntry.Hblno,
                        Id = x.HblEntry.FileGuid.Id,
                        UserId = x.User.UserName,
                        hblCount = x.HblEntry.FileGuid.Hblcount,
                        StartTime = x.StartTime

                    }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();

            }
            else
            {
                fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.FileEntry.FileNo,
                    ContainerNo = x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    UserId = _ctx.User.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime,
                    hblNo = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Hblno).FirstOrDefault(),

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();
            }
            totalRecord = fileEntryData.Count();
            IQueryable<FileActivityDataList> SortedData = fileEntryData.Distinct().AsQueryable();
            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileNo.Trim());

            }

            if (!string.IsNullOrEmpty(containerNo))
            {
                SortedData = SortedData.Where(x => x.ContainerNo == containerNo.Trim());

            }

            if (!string.IsNullOrEmpty(hblNo))
            {
                SortedData = SortedData.Where(x => x.hblNo == hblNo.Trim());

            }

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }

            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--select--")
            {
                SortedData = SortedData.Where(x => x.UserId == userName.Trim());

            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());

            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }

            if (sortColumn == "HBL")
            {
                sortColumn = "hblNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (sortColumn == "activityName")
            {
                sortColumn = "activityId";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "fileNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
            };

            return Json(returnObj);
        }


        public IActionResult GetActivityHBLData(string fileNo, string activityId, string status, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var fileActivity = _ctx.FileActivity.Include(x=>x.FileEntry).Where(x => x.FileEntry.FileNo == fileNo && x.ActivityMaster.Name == activityId).Select(x => x.ActivityId).FirstOrDefault();

            var hblEntry = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Include(x => x.User)
                            .Select(x => new HBLActivityDataList
                            {
                                Id = x.Id,
                                Hblno = x.HblEntry.Hblno,
                                FileGuidId = x.HblEntry.FileGuidId,
                                IsDap = x.HblEntry.IsDap == true ? "Yes": "No",
                                CreatedDate = x.EnterDate,
                                BasedOn = x.ActivityMaster.BasedOn,
                                CreatedBy = x.HblEntry.User.UserName,
                                Comment = x.Comment == null ? "" : x.Comment,
                                CurrentStatus = x.CurrentStatus,
                                StartTime = x.StartTime,
                                EndTime = x.EndTime,
                                EnterBy = x.EnterBy,
                                ActivityId = x.ActivityMaster.Name,
                                Activity = x.ActivityId,
                            }).ToList();

           
            var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.FileActivityId == fileActivity).Select(x => x.HBLActivityId).FirstOrDefault();
            
            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.EnterBy == userid).ToList();
            }
            if (hblEntry != null)
            {
                hblEntry = hblEntry.Where(x => x.Activity == HBLActivityMapId).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == status.Trim()).ToList();

            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }

            return Json(hblEntry);
        }

        public IActionResult GetActivityType(string fileType)
        {

            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType).ToList();
            var activity = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType).ToList();

            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string status, string comment, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            HblActivity hblActivity  = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Where(x => x.HblEntry.Hblno == model.Hblno && x.ActivityMaster.Name == model.ActivityId && x.ActivityMaster.BasedOn == model.BasedOn).FirstOrDefault();
            var fileActivityId = _ctx.FileActivity.Include(x => x.FileEntry).Where(x => x.FileEntry.Id == model.Id && x.ActivityMaster.Name == model.ActivityId).Select(x => x.ActivityId).FirstOrDefault();

            var hblActivityList = _ctx.HblActivity.Include(x => x.HblEntry).Where(x => x.HblEntry.FileGuidId == model.Id).ToList();

            if (model != null)
            {
                var hbllog = _ctx.HBLHistoryLog.Add(new HBLHistoryLog
                {

                    HBLActivityId = hblActivity.Id,
                    CurrentStatus = model.CurrentStatus,
                    Comment = model.Comment,
                    EnterBy = userid,
                    StartTime = model.StartTime,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,

                });
                _ctx.SaveChanges();

                hblActivity.EnterBy = userid;
                hblActivity.CurrentStatus = status;
                hblActivity.Comment = comment;
                hblActivity.StartTime = Convert.ToDateTime(startDate);
                hblActivity.EndTime = DateTime.Now.ToUniversalTime();
                _ctx.HblActivity.Update(hblActivity);
                _ctx.SaveChanges();

                if (model.FileGuidId != null)
                {
                    if (hblActivityList != null)
                    {
                        var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.FileActivityId == fileActivityId).Select(x => x.HBLActivityId).FirstOrDefault();

                        var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed" && x.ActivityId == HBLActivityMapId).ToList().Count();
                        if (hblStatus == 0)
                        {
                            var fileActivity = _ctx.FileActivity.Where(x => x.FileId == model.Id && x.ActivityId == hblActivity.ActivityId).FirstOrDefault();
                            if (fileActivity != null)
                            {
                                fileActivity.UserId = userid;
                                fileActivity.CurrentStatus = "Completed";
                                fileActivity.Comment = "All Hbl in this file are completed.";
                                fileActivity.StartTime = Convert.ToDateTime(startDate);
                                fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                        }

                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }

        [HttpPost]
        public IActionResult FileSubmit(FileActivityDataList model, string status, string comment, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            FileActivity fileActivity = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.ActivityMaster).Where(x => x.FileId == model.Id.Trim() && x.ActivityMaster.Name == model.ActivityId).FirstOrDefault();
            //var hblEntryList = _ctx.HblEntry.Where(x => x.FileGuidId == fileActivity.Id).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.Include(x => x.HblEntry).Where(x => x.HblEntry.FileGuidId == fileActivity.FileId).ToList();

            if (model != null)
            {
                if (model.FileNo != null)
                {
                    if (fileActivity != null)
                    {
                        var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.FileActivityId == fileActivity.ActivityId).Select(x => x.HBLActivityId).FirstOrDefault();
                        if (HBLActivityMapId != null)
                        {

                            var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed" && x.ActivityId == HBLActivityMapId).ToList().Count();
                            if (hblStatus == 0)
                            {
                                var hbllog = _ctx.FileHistoryLog.Add(new FileHistoryLog
                                {

                                    FileActivityId = fileActivity.Id,
                                    CurrentStatus = model.CurrentStatus,
                                    Comment = model.Comment,
                                    UserId = userid,
                                    StartTime = model.StartTime,
                                    EndTime = model.EndTime,
                                    EnterDate = model.EnterDate,

                                });
                                _ctx.SaveChanges();

                                var file = _ctx.FileActivity.Where(x => x.Id == fileActivity.Id && x.ActivityId == fileActivity.ActivityId).FirstOrDefault();
                                file.UserId = userid;
                                file.CurrentStatus = status;
                                file.Comment = comment;
                                file.StartTime = Convert.ToDateTime(startDate);
                                file.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(file);
                                _ctx.SaveChanges();

                            }
                            else
                            {
                                return Json("Please Update HBL in selected file");
                            }
                        }
                        else
                        {
                            return Json("MapActivity");
                        }
                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  B
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }
    }
}
