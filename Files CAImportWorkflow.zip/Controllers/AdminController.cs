﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace CAImportWorkflow.Controllers
{

    public class AdminController : Controller
    {
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;
        public AdminController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, IHostingEnvironment _hostingEnvironment)
        {
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Admin")]
        public IActionResult AdminDashboard()
        {
            ViewData["UserName"] = _ctx.User.ToList();
            ViewData["ThreadName"] = _ctx.ThreadMaster.ToList();
            return View();
        }

     

        ///Add Location
        ///
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult InsertLocation()
        {
            List<LocationMaster> locationMaster = _ctx.LocationMaster.ToList();
            return View(locationMaster);
        }

        /// <summary>
        /// Create New Location
        /// </summary>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult CreateLocation()
        {
            ViewData["LocationId"] = Guid.NewGuid().ToString();
            return PartialView();
        }

        /// <summary>
        /// Edit Location
        /// </summary>
        /// <param name="locationId"></param>
        /// <returns></returns>
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult EditLocation(string locationId)
        {
            ViewData["LocationName"] = _ctx.LocationMaster.Where(x => x.Id == locationId).FirstOrDefault();

            return PartialView();
        }


        [HttpPost]
        public JsonResult CreateLocation(LocationMaster model)
        {
            if (ModelState.IsValid)
            {
                LocationMaster locationMaster = _ctx.LocationMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (locationMaster == null)
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        _ctx.LocationMaster.Add(
                            new LocationMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                IsActive = true
                            });
                    }
                }
                else
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        locationMaster.Name = model.Name;
                        _ctx.LocationMaster.Update(locationMaster);
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        /// <summary>
        /// Activate Location        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public JsonResult ActivateLocation(string Id)
        {
            string message = "";
            if (Id != null)
            {
                LocationMaster master = _ctx.LocationMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.LocationMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Location Activated!" : master.Name + " Location Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        ///Create Activity
        ///
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult InsertActivity()
        {
            ViewData["ActivityId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.ToList();
            ViewData["ActivityList"] = _ctx.ActivityMaster.Select(x => new ActivityMasterModel { Id = x.Id, Name = x.Name, BasedOn = x.BasedOn, IsActive = x.IsActive, ThreadId = x.ThreadId, ThreadName = x.ThreadMaster.Name }).ToList();
            return PartialView();
        }


        [HttpPost]
        public JsonResult InsertActivity(ActivityMasterModel model)
        {
            if (ModelState.IsValid)
            {
                ActivityMaster activityMaster = _ctx.ActivityMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (activityMaster == null)
                {
                    ActivityMaster activityName = _ctx.ActivityMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (activityName == null)
                    {
                        _ctx.ActivityMaster.Add(
                            new ActivityMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                BasedOn = model.BasedOn,
                                ThreadId = model.ThreadId,
                                IsActive = true
                            });
                    }
                }
                else
                {
                    activityMaster.Name = model.Name;
                    activityMaster.BasedOn = model.BasedOn;
                    activityMaster.ThreadId = model.ThreadId;
                    _ctx.ActivityMaster.Update(activityMaster);
                   
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        ///Create Activity
        ///
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult InsertThread()
        {
            ViewData["ThreadId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.ToList();
            return PartialView();
        }

        [HttpPost]
        public JsonResult InsertThread(ThreadMaster model)
        {
            if (ModelState.IsValid)
            {
                ThreadMaster threadMaster = _ctx.ThreadMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (threadMaster == null)
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (threadName == null)
                    {
                        _ctx.ThreadMaster.Add(
                            new ThreadMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                Sequance = model.Sequance,
                                IsActive = true
                            });
                    }
                }
                else
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    threadMaster.Name = model.Name;
                    threadMaster.Sequance = model.Sequance;
                    _ctx.ThreadMaster.Update(threadMaster);
                   
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        ///Add File
        ///
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult InsertFile()
        {
            return View();
        }

        [HttpPost]
        public IActionResult InsertFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var act = _ctx.ActivityMaster.Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User").ToList();
            
            var present = _ctx.FileEntry.Where(x => x.ContainerNo == model.ContainerNo).FirstOrDefault();
            if (present == null)
            {
                FileEntry file = new FileEntry
                {
                    FileNo = model.FileNo,
                    ContainerNo = model.ContainerNo,
                    IsEdi = (model.IsEdi.ToUpper() == "TRUE" || model.IsEdi.ToUpper() == "YES" ? true : false),
                    Pol = model.Pol,
                    Pod = model.Pod,
                    FinalDestination = model.FinalDestination,
                    FileType = model.FileType,
                    Hblcount = model.Hblcount,
                    ActualHblcount = model.ActualHblcount,
                    Cbm = model.Cbm,
                    CoLoader = model.CoLoader,
                    SailingDate = model.SailingDate,
                    EtaAtPod = model.EtaAtPod,
                    EtaAtFD = model.EtaAtFD,
                    MBLFreightTerm = model.MBLFreightTerm,
                    HBLFreightTerm = model.HBLFreightTerm,
                    VesselName = model.VesselName,
                    ShippingLine = model.ShippingLine,
                    ContactPerson = model.ContactPerson,
                    Status = null,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = userid,

                };
                _ctx.FileEntry.Add(file);

                foreach (ActivityMaster activity in act)
                {
                    _ctx.FileActivity.Add(new FileActivity
                    {
                        Id = Guid.NewGuid().ToString(),
                        FileId = file.Id,
                        ActivityId = activity.Id,
                        CurrentStatus = "WIP",
                        Comment = null,
                        UserId = null,
                        EnterDate = DateTime.UtcNow,
                    });
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Container Already present.!");
            }

        }



        [HttpPost]
        public JsonResult GetData(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            List<FileEntryViewModel> fileEntryViewModels = new List<FileEntryViewModel>();

            fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new FileEntryViewModel
            {
                Id = x.Id,
                CreatedDate = x.CreatedDate,
                FileNo = x.FileNo,
                ContainerNo = x.ContainerNo,
                IsEdi = x.IsEdi == true ? "Yes" : "No",
                Pol = x.Pol,
                Pod = x.Pod,
                FinalDestination = x.FinalDestination,
                FileType = x.FileType,
                Hblcount = x.HblEntry.Count() != 0 ? x.HblEntry.Count().ToString() : x.Hblcount,
                Cbm = x.Cbm,
                CoLoader = x.CoLoader,
                SailingDate = x.SailingDate,
                EtaAtPod = x.EtaAtPod,
                EtaAtFD = x.EtaAtFD,
                MBLFreightTerm = x.MBLFreightTerm,
                HBLFreightTerm = x.HBLFreightTerm,
                VesselName = x.VesselName,
                ShippingLine = x.ShippingLine,
                ContactPerson = x.ContactPerson,
                ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
                AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),
                Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault() == null ? "Pending" : _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
                FileActivities = x.FileActivity.OrderByDescending(x => x.EnterDate).Select(x => new FileActivity
                {
                    ActivityMaster = x.ActivityMaster,
                    CurrentStatus = x.CurrentStatus,
                    UserId = _ctx.User.Where(y => y.Id == x.UserId).Select(y => y.UserName).FirstOrDefault(),
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate

                }).ToList(),
                HblEntry = x.HblEntry,

            }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();

            IQueryable<FileEntryViewModel> SortedData = fileEntryViewModels.AsQueryable();

            if (!string.IsNullOrEmpty(fileno))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                SortedData = SortedData.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                SortedData = SortedData.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                SortedData = SortedData.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                SortedData = SortedData.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.Status == status.Trim());

            }

            if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ThreadName == thread.Trim());

            }
            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    SortedData = SortedData.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    SortedData = SortedData.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-3) <= DateTime.Now && x.Status != "Completed");
                }
                else if (searchValue == "Received")
                {
                    SortedData = SortedData;
                }
                else if (searchValue == "UnAllocated")
                {
                    SortedData = SortedData.Where(x => x.Status == "WIP" && x.AllocatedTo == null);
                }
                else
                {
                    SortedData = SortedData.Where(x => x.Status == searchValue);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            int hblFilter = 0;
            foreach (var hblcount in SortedData.ToList())
            {
                hblFilter = SortedData.Sum(x => Convert.ToInt32(x.Hblcount));
            }
            var returnObj = new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData,
                hblCount = hblFilter
            };
            ViewData["TotalHBL"] = hblFilter;

            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult GetHblData(string fileId, string hblId)
        {

            var hblEntry = _ctx.HblEntry.Where(x => x.FileGuidId == fileId).Select(x => new HBLDataList
            {
                Id = x.Id,
                Hblno = x.Hblno == null ? "" : x.Hblno,
                FileGuidId = x.FileGuidId,
                IsDap = x.IsDap,
                CreatedDate = x.CreatedDate,
                CreatedBy = x.User.UserName == null ? "" : x.User.UserName

            }).ToList();

            var fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry).ThenInclude(x => x.User).Where(x => x.FileEntry.Id == fileId).Select(x => new FileDataList
            {
                ActivityId = x.ActivityMaster.Name,
                Comment = x.Comment == null ? "" : x.Comment,
                CurrentStatus = x.CurrentStatus,
                EndTime = x.EndTime,
                EnterDate = x.EnterDate,
                FileNo = x.FileEntry.FileNo == null ? "" : x.FileEntry.FileNo,
                Id = x.FileId,
                UserId = x.FileEntry.User.UserName == null ? "" : x.FileEntry.User.UserName,
            }).ToList();


            return Json(new { fileEntryData, hblEntry });


//            Select FileEntry.Id,FileNo,ContainerNo,Hblno,HblActivity.ActivityId, ActivityMaster.Name from FileEntry inner join HBLEntry  on FileEntry.Id = HblEntry.FileGuidId inner join HblActivity on HblEntry.Id = HblActivity.HblId
//inner join ActivityMaster on HblActivity.ActivityId = ActivityMaster.Id
//Where FileEntry.Id = 'd61bcdbf-69c9-48ac-b3cc-e0f74b8c0350' and HblActivity.CurrentStatus <> 'Completed' and HblActivity.ActivityId = '40214c14-369b-405f-9f51-3d98dc9be1b9'
        }


        public JsonResult GetDashboardValue()
        {
            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            List<FileEntryViewModel> fileEntryViewModels = new List<FileEntryViewModel>();

            fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new FileEntryViewModel
            {
                Id = x.Id,
                CreatedDate = x.CreatedDate,
                FileNo = x.FileNo,
                EtaAtPod = x.EtaAtPod,
                EtaAtFD = x.EtaAtFD,
                ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
                AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),
                Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault() == null ? "Pending" : _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),

            }).ToList();


            var now = DateTime.Now;
            AdminDashboardModel model = new AdminDashboardModel
            {
                Received = fileEntryViewModels.Count(),
                WIP = fileEntryViewModels.Count(x => x.Status == "WIP" && x.AllocatedTo != null),
                Pending = fileEntryViewModels.Count(x => x.Status == "Pending" || x.Status == "Completed With Query"),
                Completed = fileEntryViewModels.Count(x => x.Status == "Completed"),
                Query = fileEntryViewModels.Where(x => x.Status == "Query").ToList().Count,
                UnTouched = fileEntryViewModels.Count(x => x.Status == "WIP" && x.AllocatedTo == null),
                eta10 = fileEntryViewModels.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.AddDays(-10) > now && x.Status != "Completed"),
                eta12 = fileEntryViewModels.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.AddDays(-3) > now && x.Status != "Completed"),

            };

            return Json(model);

        }


        [Authorize(Roles = "Admin")]
        public ActionResult Report()
        {
            return View();
        }
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult ActivityMapping()
        {
            ViewData["HBLStatusList"] = _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL").ToList();

            var result = _ctx.ActivityMaster
                            .Where(x => x.BasedOn == "File")
                            .Select(x => new ActivityMapModel
                            {
                                FileActivityId = x.Id,
                                FileActivityName = x.Name,
                                ThreadName = x.ThreadMaster.Name,
                                HBLMappedActivityList = _ctx.ActivityMapping.Include(y => y.HBLActivityMaster).Where(y => y.FileActivityMaster.Id == x.Id).Select(y => y.HBLActivityMaster.Id).ToList()
                            }).ToList();

            return View(result);
        }

        [HttpPost]
        public IActionResult ActivityMapping(ActivityMapModel activitymap)
        {
            var assignedHBLStatus = _ctx.ActivityMapping.Where(x => x.FileActivityMaster.Id == activitymap.FileActivityId).ToList();

            try
            {
                _ctx.RemoveRange(assignedHBLStatus);

                if (activitymap.HBLMappedActivityList != null)
                    foreach (var multi in activitymap.HBLMappedActivityList)
                    {
                        _ctx.ActivityMapping.Add(new ActivityMapping
                        {
                            Id = Guid.NewGuid().ToString(),
                            FileActivityId = activitymap.FileActivityId,
                            HBLActivityId = multi.ToString(),
                            IsActive = true
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");

            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }
        public JsonResult MultiAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.FileId == multilist.eId).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            fileActivity.UserId = model.uname;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }

        }

        public JsonResult FileDetails(FileDetailsViewModel model)
        {
            var result = _ctx.FileEntry.Where(x => x.Id == model.Filedetails.Id).FirstOrDefault();
            if (result != null)
            {

            }

            return Json(model);
        }

        [HttpPost]
        public IActionResult PreAlertDataReport(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            totalRecord = data.Count();


            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            var fileEntryData = new List<FileEntryData>();
            var fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                FileNo = x.FileNo,
                ContainerNo = x.ContainerNo,
                IsEdi = x.IsEdi == true ? "Yes" : "No",
                Pol = x.Pol,
                Pod = x.Pod,
                FinalDestination = x.FinalDestination,
                FileType = x.FileType,
                Hblcount = x.Hblcount,
                Cbm = x.Cbm,
                CoLoader = x.CoLoader,
                SailingDate = x.SailingDate,
                EtaAtPod = x.EtaAtPod,
                VesselName = x.VesselName,
                ShippingLine = x.ShippingLine,
                ContactPerson = x.ContactPerson,
                ThreadName = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.ActivityMaster.ThreadMaster.Name).FirstOrDefault(),
                Status = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => y.CurrentStatus).FirstOrDefault(),
                AllocatedTo = _ctx.FileActivity.Where(y => y.FileId == x.Id).OrderByDescending(y => y.EnterDate).Select(y => _ctx.User.Where(z => z.Id == y.UserId).Select(z => z.UserName).FirstOrDefault()).FirstOrDefault(),

            }).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FinalDestination");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("Cbm");
            dt.Columns.Add("CoLoader");
            dt.Columns.Add("SailingDate");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            dt.Columns.Add("ContactPerson");
            dt.Columns.Add("ThreadName");
            dt.Columns.Add("Status");
            dt.Columns.Add("AllocatedTo");

            foreach (var file in fileEntryViewModels)
            {

                DataRow tr = dt.NewRow();
                tr[0] = file.FileNo;
                tr[1] = file.ContainerNo;
                tr[2] = file.IsEdi;
                tr[3] = file.Pol;
                tr[4] = file.Pod;
                tr[5] = file.FinalDestination;
                tr[6] = file.FileType;
                tr[7] = file.Hblcount;
                tr[8] = file.Cbm;
                tr[9] = file.CoLoader;
                tr[10] = file.SailingDate;
                tr[11] = file.EtaAtPod;
                tr[12] = file.VesselName;
                tr[13] = file.ShippingLine;
                tr[14] = file.ContactPerson;
                tr[15] = file.ThreadName;
                tr[16] = file.Status;
                tr[17] = file.AllocatedTo;
                dt.Rows.Add(tr);

            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert Report";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"PreAlertReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();

            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }


            var fileEntryData = new List<FileEntryData>();
            var fileEntryViewModels = data.Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                FileNo = x.FileNo,
                ContainerNo = x.ContainerNo,
                IsEdi = x.IsEdi == true ? "Yes" : "No",
                Pol = x.Pol,
                Pod = x.Pod,
                FinalDestination = x.FinalDestination,
                FileType = x.FileType,
                Hblcount = x.Hblcount,
                Cbm = x.Cbm,
                CoLoader = x.CoLoader,
                SailingDate = x.SailingDate,
                EtaAtPod = x.EtaAtPod,
                VesselName = x.VesselName,
                ShippingLine = x.ShippingLine,
                ContactPerson = x.ContactPerson,
            }).ToList();


            var fileActivityList = _ctx.FileEntry.Include(x => x.User).Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster).ToList();
            foreach (var file in fileActivity)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == file.Id && x.BasedOn == "File").Select(x => x.Name).FirstOrDefault(),
                        Date = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.EndTime).FirstOrDefault(),
                        Status = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.FileEntry.User.UserName).FirstOrDefault(),
                        Comment = item.FileActivity.Where(x => x.ActivityId == file.Id).Select(x => x.Comment).FirstOrDefault()
                    });
                }

            }

            DataTable dt = new DataTable();
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FinalDestination");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("Cbm");
            dt.Columns.Add("CoLoader");
            dt.Columns.Add("SailingDate");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            dt.Columns.Add("ContactPerson");
            foreach (var item in _ctx.ActivityMaster.Where(x => x.BasedOn == "File"))
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }
            foreach (var file in fileEntryViewModels)
            {
                foreach (var item in fileActivity)
                {
                    foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name))
                    {
                        DataRow tr = dt.NewRow();
                        tr[0] = file.FileNo;
                        tr[1] = file.ContainerNo;
                        tr[2] = file.IsEdi;
                        tr[3] = file.Pol;
                        tr[4] = file.Pod;
                        tr[5] = file.FinalDestination;
                        tr[6] = file.FileType;
                        tr[7] = file.Hblcount;
                        tr[8] = file.Cbm;
                        tr[9] = file.CoLoader;
                        tr[10] = file.SailingDate;
                        tr[11] = file.EtaAtPod;
                        tr[12] = file.VesselName;
                        tr[13] = file.ShippingLine;
                        tr[14] = file.ContactPerson;
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                        dt.Rows.Add(tr);
                    }
                }
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert File Log";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"FileActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertHBLDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var HBLActivity = _ctx.ActivityMaster.OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();

            IQueryable<HblEntry> data = _ctx.Set<HblEntry>().AsQueryable();

            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileGuid.FileNo == fileno.Trim());

            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileGuid.FileType == type.Trim());

            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.FileGuid.EtaAtPod == Convert.ToDateTime(etadate));

            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.FileGuid.ContainerNo == container.Trim());

            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());

            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.FileGuid.Status == status.Trim());

            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.FileGuid.Status != "Completed"));

                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.FileGuid.EtaAtPod).AddDays(-12) <= DateTime.Now && x.FileGuid.Status != "Completed");
                }

                else
                {
                    data = data.Where(x => x.FileGuid.Status == searchValue);
                }
            }
            var fileEntryData = new List<FileEntryData>();
            var HBLEntryViewModels = data.Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster.ThreadMaster).Select(x => new
            {
                FileNo = x.FileGuid.FileNo,
                ContainerNo = x.FileGuid.ContainerNo,
                Hblno = x.Hblno,
                IsDap = x.IsDap == true ? "Yes" : "No",
                CreatedBy = x.CreatedBy,
                CreatedDate = x.CreatedDate,
            }).ToList();


            var fileActivityList = _ctx.HblEntry.Include(x => x.User).Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster).ToList();
            foreach (var hbl in HBLActivity)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == hbl.Id && x.BasedOn == "HBL").Select(x => x.Name).FirstOrDefault(),
                        Date = item.HblActivity.Where(x => x.ActivityId == hbl.Id).Select(x => x.EndTime).FirstOrDefault(),
                        Status = item.HblActivity.Where(x => x.ActivityId == hbl.Id).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.HblActivity.Where(x => x.ActivityId == hbl.Id).Select(x => x.HblEntry.User.UserName).FirstOrDefault(),
                        Comment = item.HblActivity.Where(x => x.ActivityId == hbl.Id).Select(x => x.Comment).FirstOrDefault()
                    });
                }

            }

            DataTable dt = new DataTable();
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("Hblno");
            dt.Columns.Add("IsDap");
            dt.Columns.Add("CreatedBy");
            dt.Columns.Add("CreatedDate");

            foreach (var item in _ctx.ActivityMaster.Where(x => x.BasedOn == "HBL"))
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }
            foreach (var hbl in HBLEntryViewModels)
            {
                foreach (var item in HBLActivity)
                {
                    foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name))
                    {
                        DataRow tr = dt.NewRow();
                        tr[0] = hbl.FileNo;
                        tr[1] = hbl.ContainerNo;
                        tr[2] = hbl.Hblno;
                        tr[3] = hbl.IsDap;
                        tr[4] = hbl.CreatedBy;
                        tr[5] = hbl.CreatedDate;
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                        dt.Rows.Add(tr);
                    }
                }
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert HBL Log";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"HBLActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {
            return View();
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {
            if (Convert.ToDateTime(StartDate).Date == DateTime.Now.Date && Convert.ToDateTime(EndDate).Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchClick = Request.Form["columns[0][search][value]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            var fileActivity = _ctx.ActivityMaster.OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.OrderBy(x => x.Name).ToList();
            var userList = _ctx.User.ToList();

            if (StartDate != null && EndDate != null)
            {
                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();
                    var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();

                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                        });
                    }

                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
                var totalrecords = userActivityStatus.GetUserStatusList.Count();
                var SortedData = userActivityStatus.GetUserStatusList.AsQueryable();

                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    if (sortColumn == "userName")
                    {
                        sortColumn = "userId";
                    }
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                }
                var returnObj = new
                {
                    draw = draw,
                    recordsTotal = totalrecords,
                    recordsFiltered = SortedData.Count(),
                    data = SortedData,
                    skip = skip,
                    pageSize = pageSize,
                };
                return Json(returnObj);

            }
            else
            {

                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();


                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                        });

                    }
                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = _ctx.FileActivity.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
                var totalrecords = userActivityStatus.GetUserStatusList.Count();
                var SortedData = userActivityStatus.GetUserStatusList.AsQueryable();
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    if (sortColumn == "userName")
                    {
                        sortColumn = "userId";
                    }
                    SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
                }
                var returnObj = new
                {
                    draw = draw,
                    recordsTotal = totalrecords,
                    recordsFiltered = SortedData.Count(),
                    data = SortedData,
                    skip = skip,
                    pageSize = pageSize,
                };
                return Json(returnObj);
            }

        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.OrderBy(x => x.Name).ToList();
            var userList = _ctx.User.ToList();
            if (Convert.ToDateTime(StartDate).Date == DateTime.Now.Date && Convert.ToDateTime(EndDate).Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }
            if (StartDate != null && EndDate != null)
            {
                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();
                    var fileActivityList = _ctx.FileActivity.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();

                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),

                        });
                    }

                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = fileActivityList.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
            }
            else
            {

                foreach (var user in userList)
                {
                    var getFileActivityStatus = new List<FileActivityStatusList>();
                    var getHBLActivityStatus = new List<HBLActivityStatusList>();


                    foreach (var item in fileActivity)
                    {
                        getFileActivityStatus.Add(new FileActivityStatusList
                        {
                            Activity = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.Name).FirstOrDefault(),
                            ActivityType = _ctx.ActivityMaster.Where(x => x.Id == item.Id).Select(x => x.BasedOn).FirstOrDefault(),
                            WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                            Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == user.Id).Count(),
                        });

                    }
                    userActivityStatus.GetUserStatusList.Add(new UserStatusList
                    {
                        UserId = user.UserName,
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.UserId == user.Id).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.UserId == user.Id).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.UserId == user.Id).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.UserId == user.Id).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id).Count(),
                        Total = _ctx.FileActivity.Where(x => x.UserId == user.Id).Count(),
                        GetFileActivityStatus = getFileActivityStatus,
                        GetHBLActivityStatus = getHBLActivityStatus
                    });
                }
            }

            var fileStatus = userActivityStatus.GetUserStatusList.Select(x => new UserStatusList
            {
                UserId = x.UserId,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed,
                CompletedWithQuery = x.CompletedWithQuery,
                GetFileActivityStatus = x.GetFileActivityStatus

            }).ToList();

            DataTable FileActivityStatus = ToDataTable(fileStatus);

            DataTable dt = new DataTable();
            dt.Columns.Add("Username");
            dt.Columns.Add("Activity");
            dt.Columns.Add("ActivityType");
            dt.Columns.Add("Total");
            dt.Columns.Add("Completed");
            dt.Columns.Add("CompletedWithQuery");
            dt.Columns.Add("Pending");
            dt.Columns.Add("Query");
            dt.Columns.Add("WIP");



            foreach (var dr in fileStatus)
            {
                foreach (var file in dr.GetFileActivityStatus)
                {
                    DataRow tr = dt.NewRow();
                    tr[0] = dr.UserId;
                    tr[0] = dr.UserId;
                    tr[1] = file.Activity;
                    tr[2] = file.ActivityType;
                    tr[3] = file.Total;
                    tr[4] = file.Completed;
                    tr[5] = file.CompletedWithQuery;
                    tr[6] = file.Pending;
                    tr[7] = file.Query;
                    tr[8] = file.WIP;
                    dt.Rows.Add(tr);
                }
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "User Activity Status";
                var wsData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"UserActivityStatus-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            if (activityType == "HBL")
            {
                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).Include(x => x.HblEntry).ThenInclude(x => x.FileGuid).ThenInclude(x => x.FileActivity).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.HblEntry.FileGuid.FileNo,
                    ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                    hblNo = x.HblEntry.Hblno,
                    Id = x.HblEntry.FileGuid.Id,
                    UserId = x.User.UserName,
                    hblCount = x.HblEntry.FileGuid.Hblcount,
                    StartTime = x.StartTime

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();

            }
            else
            {
                fileEntryData = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry).ThenInclude(x => x.User).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    FileNo = x.FileEntry.FileNo,
                    ContainerNo = x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    UserId = x.FileEntry.User.UserName,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime

                }).Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize).ToList();
            }
            totalRecord = fileEntryData.Count();
            IQueryable<FileActivityDataList> SortedData = fileEntryData.Distinct().AsQueryable();

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }
            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());

            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());

            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "fileNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
            };

            return Json(returnObj);
        }


        public IActionResult GetActivityHBLData(string fileNo, string activityId, string status)
        {
            var fileId = _ctx.FileEntry.Where(x => x.FileNo == fileNo).Select(x => x.Id).FirstOrDefault();

            var hblEntry = (from FE in _ctx.FileEntry
                            join HE in _ctx.HblEntry on FE.Id equals HE.FileGuidId
                            join hbl in _ctx.HblActivity on HE.Id equals hbl.HblId
                            select new HBLActivityDataList
                            {
                                Id = HE.Id,
                                Hblno = HE.Hblno,
                                FileGuidId = HE.FileGuidId,
                                IsDap = HE.IsDap == true? "Yes":"No",
                                CreatedDate = HE.CreatedDate,
                                BasedOn = _ctx.ActivityMaster.Where(y => y.Id == hbl.ActivityId).Select(x => x.BasedOn).FirstOrDefault(),
                                CreatedBy = _ctx.User.Where(y => y.Id == HE.CreatedBy).Select(y => y.UserName).FirstOrDefault(),
                                Comment = hbl.Comment,
                                CurrentStatus = hbl.CurrentStatus,
                                StartTime = hbl.StartTime,
                                EndTime = hbl.EndTime,
                                EnterBy = hbl.EnterBy,
                                ActivityId = _ctx.HblActivity.Where(y => y.ActivityId == hbl.ActivityId).Select(y => y.ActivityMaster.Name).FirstOrDefault(),
                            }).ToList();

            if (activityId == "File Processing Status")
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == "HBL Status").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == activityId).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == status.Trim()).ToList();

            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }
            
            return Json(hblEntry);
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblId)
        {
            ViewData["hblActivityList"] = _ctx.HblActivity.Where(x => x.HblId == hblId).Select(x => new HBLActivityDataList
            {
                Id = x.Id,
                Hblno = x.HblEntry.Hblno == null ? "" : x.HblEntry.Hblno,
                ActivityId = x.ActivityMaster.Name,
                EndTime = x.EndTime,
                CurrentStatus = x.CurrentStatus,
                Comment = x.Comment == null ? "" : x.Comment,
                EnterBy = x.User.CitrixId == null ? "" : x.User.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivityData(string hblno, string hbl)
        {
            var hblact = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).Include(x => x.User).Where(x => x.HblEntry.Hblno == hblno).ToList();
            List<HBLActivityDataList> hblActivityLog = new List<HBLActivityDataList>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityDataList
                {
                    Hblno = hblno == null ? "" : hblno,
                    ActivityId = item.ActivityMaster.Name == null ? "" : item.ActivityMaster.Name,
                    EndTime =item.EndTime,
                    CurrentStatus = item.CurrentStatus,
                    EnterBy = item.User.CitrixId,

                });
            }
            return Json(hblActivityLog);
        }
        public IActionResult GetActivityType(string fileType)
        {

            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType).ToList();
            var activity = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType).ToList();

            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string fileType, string activityId, string status, DateTime startDate)
        {
            var activity = _ctx.ActivityMaster.Where(x => x.BasedOn == fileType).ToList();
            var hblId = _ctx.HblEntry.Where(x => x.Hblno == model.Hblno).Select(x => x.Id).FirstOrDefault();
            var hblActivityId = _ctx.HblActivity.Where(x => x.HblId == hblId).Select(x => x.Id).FirstOrDefault();
            HblActivity hblActivity = _ctx.HblActivity.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.Where(x => x.HblEntry.FileGuidId == model.FileGuidId).ToList();
            if (fileType == "HBL")
            {
                var hbllog = _ctx.HBLHistoryLog.Add(new HBLHistoryLog               
                {

                    HBLActivityId = hblActivityId,
                    CurrentStatus = model.CurrentStatus,
                    Comment = model.Comment,
                    EnterBy = model.EnterBy,
                    StartTime = startDate,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,

                });
                _ctx.SaveChanges();

                hblActivity.CurrentStatus = model.CurrentStatus;
                hblActivity.Comment = model.Comment;
                hblActivity.StartTime = startDate;
                hblActivity.EndTime = DateTime.Now.ToUniversalTime();
                _ctx.HblActivity.Update(hblActivity);
                _ctx.SaveChanges();

                if (model.FileGuidId != null)
                {
                    if (hblActivityList != null)
                    {
                        foreach (var hbl in hblActivityList)
                        {
                            var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed").Count();
                            if (hblStatus == 0)
                            {
                                var fileActivity = _ctx.FileActivity.Where(x => x.FileId == model.FileGuidId).FirstOrDefault();
                                fileActivity.CurrentStatus = model.CurrentStatus;
                                fileActivity.Comment = "All Hbl in this file are completed.";
                                fileActivity.StartTime = startDate;
                                fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                        }
                    }

                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }
    }
}


