﻿namespace CAImportWorkflow.Models
{
    public class ActivityMasterModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; }
        public string BasedOn { get; set; }
        public bool IsActive { get; set; }
        public string ThreadId { get; set; }
        public string? ThreadName { get; set; }
    }
}
