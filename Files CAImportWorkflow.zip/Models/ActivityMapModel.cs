﻿namespace CAImportWorkflow.Models
{
    public class ActivityMapModel
    {
        public string FileActivityId { get; set; }
        public string FileActivityName { get; set; }
        public string ThreadName { get; set; }
        public List<string> HBLMappedActivityList { get; set; }

    }
}
