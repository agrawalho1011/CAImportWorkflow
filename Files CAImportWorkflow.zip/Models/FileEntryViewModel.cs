﻿using CAImportWorkflow.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CAImportWorkflow.Models
{
    public class FileEntryViewModel
    {

        public string? Id { get; set; }
        public string? FileNo { get; set; }

        [Required(ErrorMessage = "Please provide a value for container field")]
        public string? ContainerNo { get; set; }
        public string? IsEdi { get; set; }

      
        public string? Pol { get; set; }

     
        public string? Pod { get; set; }
        public string? FinalDestination { get; set; }
        public string? FileType { get; set; }
        public string? Hblcount { get; set; }
        public string? ActualHblcount { get; set; }
        public string? Cbm { get; set; }
        public string? CoLoader { get; set; }
        public DateTime? SailingDate { get; set; }

      
        public DateTime? EtaAtPod { get; set; }
        public DateTime? EtaAtFD { get; set; }
        public string? MBLFreightTerm { get; set; }
        public string? HBLFreightTerm { get; set; }
        public string? VesselName { get; set; }
        public string? ShippingLine { get; set; }
        public string? ContactPerson { get; set; }
        public string? Status { get; set; }
        public string? ThreadName { get; set; }
        public string? AllocatedTo { get; set; }
        public string? AllocatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public virtual ICollection<FileActivity>? FileActivities { get; set; }
        public virtual ICollection<HblEntry>? HblEntry { get; set; }
        public virtual ICollection<FileEntryData>? FileEntryData { get; set; }
        public virtual ICollection<FileEntryData>? HBLEntryData { get; set; }

    }
}
