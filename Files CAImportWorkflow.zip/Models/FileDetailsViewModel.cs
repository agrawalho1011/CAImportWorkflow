﻿using CAImportWorkflow.Data;

namespace CAImportWorkflow.Models
{
    public class FileDetailsViewModel
    {
       public FileEntry Filedetails { get; set; }
    }
}
