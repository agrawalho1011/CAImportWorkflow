﻿using CAImportWorkflow.Data;

namespace CAImportWorkflow.Models
{
    public class SubmitDataViewModel
    {
        public List<FileData>? file { get; set; }
       
        public List<FileActivityStatus>? FileActivityStatusSubmit { get; set; }
        public List<HblDataSubmitViewModel>? HBLDataSubmit { get; set; }
        public List<ActivityMaster>? Activities { get; set; }
    }

    public class FileData
    {
        public string Id { get; set; }
        public string FileNo { get; set; }
        public string? ContainerNo { get; set; }
        public string? pol { get; set; }
        public string? pod { get; set; }
        public string? fpod { get; set; }
        public DateTime? ETAatPOD { get; set; }
        public DateTime? ETAatFD { get; set; }
        public string? Hblcount { get; set; }
    }

    public class FileActivityStatus
    {
        public string ActivityId { get; set; }
        public string CurrentStatus { get; set; }
        public string Comments { get; set; }
        public DateTime? StartTime { get; set; }
    }
    public class HblDataSubmitViewModel
    {
        public string HblNo { get; set; }
        public string? IsDap { get; set; }

        public List<HBLActivityStatus> HBLActivityStatuses { get; set; }
    }

    public class HBLActivityStatus
    {
        public string ActivityId { get; set; } 
        public string Status { get; set; }
        public string HblComments { get; set; }
        public DateTime? StartTime { get; set; }
    }



}
